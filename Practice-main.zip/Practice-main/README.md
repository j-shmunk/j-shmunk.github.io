# Jacob Haynes
## Biography
#### Hi everyone, My name is jacob Haynes I am a Sophomore at Juniata College and I also play soccer here as a center midfielder and I wear #10. I am from Atlanta, Georgia born and raised and I have one older sister and one younger brother. In my free time I enjoy:
* Watching movies & TV shows
* Expereincing new things with my friends
* Eating out at new places
* Sleeping
## Personal Statement
#### As a Business IT major, I'm driven by a passion for leveraging technology to solve complex business chllenges. My goal is to pursuea career as an IT consultant, where I can apply my technical expertise to help organizations optimize their operations and achieve their strategic objectives. I am eager to contribute my skills and knowledge to dynamic teams and work collaboratively with clients to deliver innovative solutions.
## Academic Interests
* Learning how to use database management systems like SQL
* UNderstanding network infrastructure
* Cybersecurity
## Programming Interests
* Learning html, Java, or Javascript
* Genuinely understanding how it works
## Research Interests
* Data Science: The role of programming in data analysis, visualization, and modeling.
* Cybersecurity: Investigate programming techniques used to protect systems from cyber threats.
* Digital Ethics: The ethical considerations of programming and technology, including bias, privacy, and accessibility.
